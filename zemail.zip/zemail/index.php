<!DOCTYPE html>
<html data-bs-theme="light" lang="en-US" dir="ltr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- ===============================================--><!--    Document Title--><!-- ===============================================-->
    <title>Zmail | Smtp</title>

    <!-- ===============================================--><!--    Favicons--><!-- ===============================================-->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">
    <meta name="theme-color" content="#ffffff">

    <!-- ===============================================--><!--    Stylesheets--><!-- ===============================================-->
    <link rel="stylesheet" href="vendors/swiper/swiper-bundle.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,300..900;1,300..900&amp;family=Rubik:ital,wght@0,300..900;1,300..900family=Rubik:ital,wght@0,300..900;1,300..900&amp;display=swap" rel="stylesheet">
    <link href="assets/css/theme.min.css" rel="stylesheet" id="style-default">
    <link href="assets/css/user-rtl.min.css" rel="stylesheet" id="user-style-rtl">
    <link href="assets/css/user.min.css" rel="stylesheet" id="user-style-default">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.8/css/line.css">
  </head>

<body>
<main class="main" id="top">
    <div class="main">

    <div class="content">
           


            <div data-bs-target="#navbar" data-bs-spy="scroll" tabindex="0">
          <section class="hero-section overflow-hidden position-relative z-0 mb-4 mb-lg-0" id="home">
            <div class="hero-background">
              <div class="container">
                <div class="row gy-4 gy-md-8 pt-9 pt-lg-0">
                  <div class="col-lg-6 text-center text-lg-start">
                    <h1 class="fs-2 fs-lg-1 text-white fw-bold mb-2 mb-lg-x1 lh-base mt-3 mt-lg-0"> 
                    Send Email with File Attachment <span class="text-nowrap">in PHP</span></h1>
                    <p class="fs-8 text-white mb-3 mb-lg-4 lh-lg">
 This simple PHP script allows you to send an email with an attached file to any recipient
 , Before using this script, ensure that you have configured your SMTP settings correctly. Check the <b>send-email.php </b>file for detailed instructions on setting up your SMTP server. </p>
                    
                   
                    
                  </div>
                  <div class="col-lg-6 position-lg-relative">



            <form action="./send-email.php" method="POST" enctype="multipart/form-data">
            <div class="mb-2 w-100">
                <label for="email">To:</label>
                <div class="input-group is-invalid">
                    <div class="input-group-prepend">
                        <span class="input-group-text">@</span>
                    </div>
                    <input placeholder="To:" type="text" class="form-control" name="email" id="email" required>
                </div>
            </div>
                <div class="form-group">
                    <label for="subject">Subject:</label>
                    <input type="text" class="form-control" id="subject" name="subject" required>
                </div>
                <div class="form-group">
                    <label for="message">Message:</label>
                    <textarea class="form-control" name="message" id="message" cols="30" rows="7" required></textarea>
                </div>
                <label for="file">File:</label>
                <div class="custom-file mb-3">
                    <input type="file" class="form-control" id="file" name="file" required onchange="updateFileName()">
                    <label class="custom-file-label" for="file" id="file-label">Choose file...</label>
                </div>
                <button type="submit" class="btn btn-lg btn-primary lh-xl mb-x1">Send Email</button>
            </form>


            </div>
                </div>
              </div>
            </div>

            </section>
        </div>

    </div>


    </main>
    

    <!-- ===============================================--><!--    JavaScripts--><!-- ===============================================-->
    <script src="vendors/popper/popper.min.js"></script>
    <script src="vendors/bootstrap/bootstrap.min.js"></script>
    <script src="vendors/is/is.min.js"></script>
    <script src="vendors/countup/countUp.umd.js"></script>
    <script src="vendors/swiper/swiper-bundle.min.js"></script>
    <script src="vendors/lodash/lodash.min.js"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
    <script src="assets/js/theme.js"></script>



    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function updateFileName() {
            // Get the file input
            var fileInput = document.getElementById('file');

            // Get the file label
            var fileLabel = document.getElementById('file-label');

            // Update the label text with the selected file name
            fileLabel.innerText = fileInput.files.length > 0 ? fileInput.files[0].name : 'Choose file...';
        }
    </script>
</body>
</html>